<?php 

$con = mysqli_connect('localhost', 'u915573196_shxxter', 'Turboisbest@1', 'u915573196_turbo');
if(!$con){
    die("Connection Failed");
}

?>